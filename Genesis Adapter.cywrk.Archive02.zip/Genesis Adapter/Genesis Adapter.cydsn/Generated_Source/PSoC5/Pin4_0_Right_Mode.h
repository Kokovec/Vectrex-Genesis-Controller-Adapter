/*******************************************************************************
* File Name: Pin4_0_Right_Mode.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pin4_0_Right_Mode_H) /* Pins Pin4_0_Right_Mode_H */
#define CY_PINS_Pin4_0_Right_Mode_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Pin4_0_Right_Mode_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Pin4_0_Right_Mode__PORT == 15 && ((Pin4_0_Right_Mode__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Pin4_0_Right_Mode_Write(uint8 value);
void    Pin4_0_Right_Mode_SetDriveMode(uint8 mode);
uint8   Pin4_0_Right_Mode_ReadDataReg(void);
uint8   Pin4_0_Right_Mode_Read(void);
void    Pin4_0_Right_Mode_SetInterruptMode(uint16 position, uint16 mode);
uint8   Pin4_0_Right_Mode_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Pin4_0_Right_Mode_SetDriveMode() function.
     *  @{
     */
        #define Pin4_0_Right_Mode_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Pin4_0_Right_Mode_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Pin4_0_Right_Mode_DM_RES_UP          PIN_DM_RES_UP
        #define Pin4_0_Right_Mode_DM_RES_DWN         PIN_DM_RES_DWN
        #define Pin4_0_Right_Mode_DM_OD_LO           PIN_DM_OD_LO
        #define Pin4_0_Right_Mode_DM_OD_HI           PIN_DM_OD_HI
        #define Pin4_0_Right_Mode_DM_STRONG          PIN_DM_STRONG
        #define Pin4_0_Right_Mode_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Pin4_0_Right_Mode_MASK               Pin4_0_Right_Mode__MASK
#define Pin4_0_Right_Mode_SHIFT              Pin4_0_Right_Mode__SHIFT
#define Pin4_0_Right_Mode_WIDTH              1u

/* Interrupt constants */
#if defined(Pin4_0_Right_Mode__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Pin4_0_Right_Mode_SetInterruptMode() function.
     *  @{
     */
        #define Pin4_0_Right_Mode_INTR_NONE      (uint16)(0x0000u)
        #define Pin4_0_Right_Mode_INTR_RISING    (uint16)(0x0001u)
        #define Pin4_0_Right_Mode_INTR_FALLING   (uint16)(0x0002u)
        #define Pin4_0_Right_Mode_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Pin4_0_Right_Mode_INTR_MASK      (0x01u) 
#endif /* (Pin4_0_Right_Mode__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Pin4_0_Right_Mode_PS                     (* (reg8 *) Pin4_0_Right_Mode__PS)
/* Data Register */
#define Pin4_0_Right_Mode_DR                     (* (reg8 *) Pin4_0_Right_Mode__DR)
/* Port Number */
#define Pin4_0_Right_Mode_PRT_NUM                (* (reg8 *) Pin4_0_Right_Mode__PRT) 
/* Connect to Analog Globals */                                                  
#define Pin4_0_Right_Mode_AG                     (* (reg8 *) Pin4_0_Right_Mode__AG)                       
/* Analog MUX bux enable */
#define Pin4_0_Right_Mode_AMUX                   (* (reg8 *) Pin4_0_Right_Mode__AMUX) 
/* Bidirectional Enable */                                                        
#define Pin4_0_Right_Mode_BIE                    (* (reg8 *) Pin4_0_Right_Mode__BIE)
/* Bit-mask for Aliased Register Access */
#define Pin4_0_Right_Mode_BIT_MASK               (* (reg8 *) Pin4_0_Right_Mode__BIT_MASK)
/* Bypass Enable */
#define Pin4_0_Right_Mode_BYP                    (* (reg8 *) Pin4_0_Right_Mode__BYP)
/* Port wide control signals */                                                   
#define Pin4_0_Right_Mode_CTL                    (* (reg8 *) Pin4_0_Right_Mode__CTL)
/* Drive Modes */
#define Pin4_0_Right_Mode_DM0                    (* (reg8 *) Pin4_0_Right_Mode__DM0) 
#define Pin4_0_Right_Mode_DM1                    (* (reg8 *) Pin4_0_Right_Mode__DM1)
#define Pin4_0_Right_Mode_DM2                    (* (reg8 *) Pin4_0_Right_Mode__DM2) 
/* Input Buffer Disable Override */
#define Pin4_0_Right_Mode_INP_DIS                (* (reg8 *) Pin4_0_Right_Mode__INP_DIS)
/* LCD Common or Segment Drive */
#define Pin4_0_Right_Mode_LCD_COM_SEG            (* (reg8 *) Pin4_0_Right_Mode__LCD_COM_SEG)
/* Enable Segment LCD */
#define Pin4_0_Right_Mode_LCD_EN                 (* (reg8 *) Pin4_0_Right_Mode__LCD_EN)
/* Slew Rate Control */
#define Pin4_0_Right_Mode_SLW                    (* (reg8 *) Pin4_0_Right_Mode__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Pin4_0_Right_Mode_PRTDSI__CAPS_SEL       (* (reg8 *) Pin4_0_Right_Mode__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Pin4_0_Right_Mode_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Pin4_0_Right_Mode__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Pin4_0_Right_Mode_PRTDSI__OE_SEL0        (* (reg8 *) Pin4_0_Right_Mode__PRTDSI__OE_SEL0) 
#define Pin4_0_Right_Mode_PRTDSI__OE_SEL1        (* (reg8 *) Pin4_0_Right_Mode__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Pin4_0_Right_Mode_PRTDSI__OUT_SEL0       (* (reg8 *) Pin4_0_Right_Mode__PRTDSI__OUT_SEL0) 
#define Pin4_0_Right_Mode_PRTDSI__OUT_SEL1       (* (reg8 *) Pin4_0_Right_Mode__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Pin4_0_Right_Mode_PRTDSI__SYNC_OUT       (* (reg8 *) Pin4_0_Right_Mode__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Pin4_0_Right_Mode__SIO_CFG)
    #define Pin4_0_Right_Mode_SIO_HYST_EN        (* (reg8 *) Pin4_0_Right_Mode__SIO_HYST_EN)
    #define Pin4_0_Right_Mode_SIO_REG_HIFREQ     (* (reg8 *) Pin4_0_Right_Mode__SIO_REG_HIFREQ)
    #define Pin4_0_Right_Mode_SIO_CFG            (* (reg8 *) Pin4_0_Right_Mode__SIO_CFG)
    #define Pin4_0_Right_Mode_SIO_DIFF           (* (reg8 *) Pin4_0_Right_Mode__SIO_DIFF)
#endif /* (Pin4_0_Right_Mode__SIO_CFG) */

/* Interrupt Registers */
#if defined(Pin4_0_Right_Mode__INTSTAT)
    #define Pin4_0_Right_Mode_INTSTAT            (* (reg8 *) Pin4_0_Right_Mode__INTSTAT)
    #define Pin4_0_Right_Mode_SNAP               (* (reg8 *) Pin4_0_Right_Mode__SNAP)
    
	#define Pin4_0_Right_Mode_0_INTTYPE_REG 		(* (reg8 *) Pin4_0_Right_Mode__0__INTTYPE)
#endif /* (Pin4_0_Right_Mode__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Pin4_0_Right_Mode_H */


/* [] END OF FILE */
