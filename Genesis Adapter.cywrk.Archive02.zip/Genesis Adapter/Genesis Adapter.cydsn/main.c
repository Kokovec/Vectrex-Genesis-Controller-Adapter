/* ========================================
 *
 * SEGA 6-Button Controller to Vectrex Adapter
 * By Dan Siewers (Kokovec)
 *
 * ========================================
*/

#include "project.h"

// Function prototype: SPI Write function for Digital Pots
void Write_To_SPI_Pot(uint8 pot, uint8 tx_data);

// This struct holds all button states
struct Button_States {
    uint8   UP;
    uint8   DOWN;
    uint8   LEFT;
    uint8   RIGHT;
    uint8   A;
    uint8   B;
    uint8   C;
    uint8   Z;
    uint8   Y;
    uint8   X;
}Button_State;

uint8 pulse = 0;                // iterator variable for SELECT pulses sent to controller

// Main program starts here
int main(void)
{
    Pin_7_Select_Write(1);      // We start with controller Select pin High
    Pin_LED_Write(1);           // Light up the green LED on the Schmartboard
    CyDelay(1000);              // Give controller a second to warm up
    CyGlobalIntEnable;          // Enable global interrupts
    SPIM_Joy_Start();           // Start SPI interface for Digital POTs
    Write_To_SPI_Pot(0, 127);   // Center POT-X
    Write_To_SPI_Pot(1, 127);   // Center POT-Y
    Pin_LED_Write(0);           // Turn off green LED on Schmartboard

    // Main loop starts here
    for(;;)
    {
        /*
         * The Sega 6-Button controller is backwards compatible with the 3-button controllers
         * Because of this we need to send out 3 SELECT pulses in order to capture all of the buttons
         * See table on design schematic for details
        */
        
        // First 2 SELECT pulses used to capture all buttons except X,Y,Z
        for(pulse=0; pulse<3; pulse++) {

            Pin_7_Select_Write(1);                          // SELECT line high                        
            CyDelayUs(12);                                  // "Hold" tim (microseconds)
            Button_State.UP = Pin_1_UP_UP_Z_Read();         // Read Joy Up
            Button_State.DOWN = Pin2_Down_Down_Y_Read();    // Read Joy Down
            Button_State.LEFT = Pin3_0_Left_X_Read();       // Read Joy Left
            Button_State.RIGHT = Pin4_0_Right_Mode_Read();       // Read Joy Right
            Button_State.B = Pin6_A_B_Read();               // Read button B
            Button_State.C = Pin9_Start_C_Read();           // read button C
            
            Pin_7_Select_Write(0);                          // SELECT line low
            CyDelayUs(12);                                  // "Hold" time (microseconds)
            Button_State.A = Pin6_A_B_Read();               // Read button A
        }
            
        // 3rd Pulse used to read X,Y,Z buttons
        Pin_7_Select_Write(1);                              // SELECT line high
        CyDelayUs(12);
        Button_State.Z = Pin_1_UP_UP_Z_Read();              // Read Button Z
        Button_State.Y = Pin2_Down_Down_Y_Read();           // Read Button Y
        Button_State.X = Pin3_0_Left_X_Read();              // Read Button X
        
        // 4th pulse to "reset" controller state (short pulse)
        Pin_7_Select_Write(0);                              // SELECT line low
        CyDelayUs(5);                                       // "Hold" time (microseconds)
        Pin_7_Select_Write(1);                              // SELECT line high
        
        // Map buttons to vectrex pins
        Pin_Vectrex_Button_4_Write(Button_State.A);         // Sega A -> Vectrex 4
        Pin_Vectrex_Button_3_Write(Button_State.B);         // Sega B -> Vectrex 3
        Pin_Vectrex_Button_2_Write(Button_State.C);         // Sega C -> Vectrex 2
        Pin_Vectrex_Button_1_Write(Button_State.Z);         // Sega D -> Vectrex 1
        
        // Map Sega joy pad to Vectrex Y pots
        if(Button_State.UP == 0) {
            Write_To_SPI_Pot(1, 255);      // Set POT-Y to UP position
        }
        else if(Button_State.DOWN == 0) {
            Write_To_SPI_Pot(1, 0);        // Set POT-Y to DOWN position
        }
        else {
            Write_To_SPI_Pot(1, 127);      // Set POT-Y to center position
        }
        
        // Map Sega joy pad to Vectrex X pots
        if(Button_State.RIGHT == 0) {
            Write_To_SPI_Pot(0, 255);      // Set POT-X to UP position
        }
        else if(Button_State.LEFT == 0) {
            Write_To_SPI_Pot(0,0);        // Set POT-X to DOWN position
        }
        else {
            Write_To_SPI_Pot(0,127);      // Set POT-X to center position
        }
        
        // Set this delay for Sega controller polling rate
        // Might need adjustment depending on type of controller
        // [10 = ~100Hz] [16 = ~60Hz]
        CyDelay(10);                    // Delay between polling cycles (milliseconds)
    }
}

/*
 * This function handles writing 8 bit values to the digital pots
 * Digital pots: Analog AD5290YRMZ10 (Mouser part#: 584-AD5290YRMZ10)
 * There are 2 digital pots. One fed to Vectrex Pot-X and one fed to Pot-Y.
 * The SDI and CLK lines are looped between digital pots
 * CS lines are fed to each pot individually (via control register POT_Select)
 * Function params:
 *      Inputs:
 *              uint8 pot       0 = digital pot chip select for X
 *                              1 = digital pot chip select for Y
 *              
 *              uint8 tx_data   8 bit data fed to the digital pot via SPI
 */
void Write_To_SPI_Pot(uint8 pot, uint8 tx_data)
{
    uint8 temp;
    // Clear the TX buffer
    SPIM_Joy_ClearTxBuffer();
    // Ensure that previous SPI read is done, or SPI is idle before sending data
    temp = SPIM_Joy_ReadTxStatus();
    while(!(temp & (SPIM_Joy_STS_SPI_DONE | SPIM_Joy_STS_SPI_IDLE)));
    // Select the pot (X or Y)
    POT_Select_Write(pot);
    // Send the data
    SPIM_Joy_WriteTxData(tx_data);
    // Ensure data is sent before returning from function
    while( ! (SPIM_Joy_ReadTxStatus() & SPIM_Joy_STS_BYTE_COMPLETE  ) );
}

/* [] END OF FILE */
